function LogOut(element) {
    element.innerText = "LogOut";
}

function Remove1(element) {
    element.remove();
}
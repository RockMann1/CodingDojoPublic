var riderHeight = 41;
var minAge = 10;
if (riderHeight >= 42) {
    console.log("Get on that ride, Kiddo!!"); 
}
else { 
    console.log("Sorry Kiddo, maybe next year!!");
}
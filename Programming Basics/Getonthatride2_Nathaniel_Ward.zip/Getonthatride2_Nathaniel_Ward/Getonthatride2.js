let riderHeight = 41;
let minAge = 11;

if (riderHeight >= 42 && minAge >= 10) { // using && operator, cited from lecture and class input this week.
    console.log("Get on that ride kiddo, NOW!")
}
else {
    console.log("Get the heck out of here what the hell!?")
}

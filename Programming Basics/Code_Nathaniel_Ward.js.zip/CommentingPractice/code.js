// This variable will hold the likeCount value, which is now 0.
var likeCount = 0;

// This code block will hold the function of increasing likes
function increaseLikes() {
    
    // This operation is for adding value of 1 to the likeCount variable.
likeCount = likeCount +1;

}
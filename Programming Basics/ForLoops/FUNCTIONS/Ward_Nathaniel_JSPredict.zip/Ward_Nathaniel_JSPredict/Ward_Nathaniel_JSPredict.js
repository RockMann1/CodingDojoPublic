//Predict 1: 
// A: I was born in1980

//Predict 2: 
// A: I was born in1980

//Predict 3:
// A: 
//Summing Numbers!
//num1 is: 10
//num2 is: 20
//30